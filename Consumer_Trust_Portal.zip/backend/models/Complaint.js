const mongoose = require("mongoose");

const complaintSchema = new mongoose.Schema(
  {
    complaintId: {
      type: String,
      required: true,
      unique: true,
      index: true,
    },
    docketNumber: {
      type: String,
      index: true,
      default: function () {
        return this.complaintId;
      },
    },
    name: {
      type: String,
      required: [true, "Name is required"],
      trim: true,
    },
    citizenName: {
      type: String,
      trim: true,
      default: function () {
        return this.name;
      },
    },
    email: {
      type: String,
      required: [true, "Email is required"],
      trim: true,
      lowercase: true,
    },
    citizenEmail: {
      type: String,
      trim: true,
      lowercase: true,
      default: function () {
        return this.email;
      },
    },
    phone: {
      type: String,
      required: [true, "Phone number is required"],
      trim: true,
    },
    citizenPhone: {
      type: String,
      trim: true,
      default: function () {
        return this.phone;
      },
    },
    category: {
      type: String,
      required: [true, "Category is required"],
      enum: [
        "Product",
        "Service",
        "Food",
        "Banking",
        "Telecom",
        "Travel",
        "Electronics",
        "Automotive",
        "E-Commerce",
        "Real Estate",
        "Healthcare",
        "Education",
        "Insurance",
        "Utilities",
        "Other",
      ],
      default: "Product",
    },
    companyName: {
      type: String,
      default: "General Enterprise",
      trim: true,
      index: true,
    },
    companyEmail: {
      type: String,
      default: "",
      trim: true,
      lowercase: true,
    },
    productName: {
      type: String,
      default: "",
      trim: true,
    },
    reliefRequested: {
      type: String,
      default: "",
      trim: true,
    },
    transactionValue: {
      type: Number,
      default: 0,
    },
    orderOrTransactionId: {
      type: String,
      default: "",
      trim: true,
    },
    resolutionToken: {
      type: String,
      default: null,
      index: true,
    },
    companyNoticeSent: {
      type: Boolean,
      default: false,
    },
    companyNoticeSentAt: {
      type: Date,
      default: null,
    },
    speedPostTrackingNumber: {
      type: String,
      default: "",
      trim: true,
    },
    speedPostBookedAt: {
      type: Date,
      default: null,
    },
    noticeDispatchedAt: {
      type: Date,
      default: null,
    },
    companyResolution: {
      actionTaken: { type: String, default: "" },
      refundAmount: { type: Number, default: 0 },
      referenceNumber: { type: String, default: "" },
      resolutionNotes: { type: String, default: "" },
      resolvedBy: { type: String, default: "" },
      resolvedAt: { type: Date, default: null },
    },
    escalatedToOmbudsman: {
      type: Boolean,
      default: false,
    },
    escalatedAt: {
      type: Date,
      default: null,
    },
    subject: {
      type: String,
      required: [true, "Complaint subject is required"],
      trim: true,
    },
    description: {
      type: String,
      required: [true, "Complaint description is required"],
      trim: true,
    },
    status: {
      type: String,
      enum: [
        "Pending",
        "Under Review",
        "Notice Dispatched",
        "In Progress",
        "Statutory Escalation",
        "Resolved",
        "Rejected",
      ],
      default: "Pending",
      index: true,
    },
    priority: {
      type: String,
      enum: ["Low", "Medium", "High", "Urgent"],
      default: "Medium",
    },
    user: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "User",
      default: null,
    },
    userId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "User",
      default: function () {
        return this.user;
      },
    },
    adminRemarks: {
      type: String,
      default: "",
      trim: true,
    },
    resolvedAt: {
      type: Date,
      default: null,
    },
    attachments: [
      {
        originalName: { type: String, required: true },
        filename: { type: String, required: true },
        path: { type: String },
        url: { type: String, required: true },
        mimeType: { type: String },
        size: { type: Number },
      },
    ],
    feedback: {
      rating: { type: Number, min: 1, max: 5, default: null },
      comments: { type: String, default: "" },
      submittedAt: { type: Date, default: null },
    },
    smsAlertsEnabled: {
      type: Boolean,
      default: true,
    },
    whatsappAlertsEnabled: {
      type: Boolean,
      default: true,
    },
    whatsappLogs: [
      {
        message: { type: String },
        phone: { type: String },
        status: { type: String, default: "DELIVERED" },
        provider: { type: String, default: "WhatsApp Cloud Gateway" },
        sentAt: { type: Date, default: Date.now },
      },
    ],
    smsLogs: [
      {
        message: { type: String },
        phone: { type: String },
        status: { type: String, default: "DELIVERED" },
        provider: { type: String, default: "Telecom Gateway" },
        sentAt: { type: Date, default: Date.now },
      },
    ],
  },
  {
    timestamps: true,
  }
);

module.exports = mongoose.model("Complaint", complaintSchema);
