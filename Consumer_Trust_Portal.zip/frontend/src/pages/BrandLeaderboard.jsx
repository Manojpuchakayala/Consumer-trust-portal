import { useState } from "react";
import { Link } from "react-router-dom";
import {
  FaBuilding,
  FaShieldAlt,
  FaClock,
  FaSearch,
  FaStar,
  FaEnvelope,
  FaInfoCircle,
  FaArrowRight,
  FaTimes,
  FaUsers,
  FaCheckCircle,
  FaGavel,
  FaExternalLinkAlt,
  FaCopy,
  FaCheck,
  FaPhoneAlt,
  FaExclamationTriangle,
} from "react-icons/fa";
import ResolutionTicker from "../components/ResolutionTicker";
import "./BrandLeaderboard.css";

const BRAND_DATA = [
  // ==========================================
  // 1. E-COMMERCE, RETAIL & QUICK COMMERCE
  // ==========================================
  {
    id: "amazon",
    name: "Amazon India",
    category: "E-Commerce",
    resolutionRate: "96.4%",
    avgDays: "2.8 Days",
    totalCases: 1420,
    nodalEmail: "grievance-officer@amazon.in",
    rating: 4.8,
    authority: "E-Commerce Rules / Voluntary Nodal Desk",
    sla: "48h Ack / 7 Days Target",
    badge: "Active Nodal Desk",
    badgeColor: "#059669",
    color: "#2563eb",
  },
  {
    id: "flipkart",
    name: "Flipkart",
    category: "E-Commerce",
    resolutionRate: "94.8%",
    avgDays: "3.2 Days",
    totalCases: 1280,
    nodalEmail: "grievance.officer@flipkart.com",
    rating: 4.6,
    authority: "E-Commerce Rules / Voluntary Nodal Desk",
    sla: "48h Ack / 7 Days Target",
    badge: "Active Nodal Desk",
    badgeColor: "#2563eb",
    color: "#2563eb",
  },
  {
    id: "myntra",
    name: "Myntra",
    category: "E-Commerce",
    resolutionRate: "95.2%",
    avgDays: "2.9 Days",
    totalCases: 640,
    nodalEmail: "grievanceofficer@myntra.com",
    rating: 4.7,
    authority: "Fashion Grievance Desk",
    sla: "48h Ack / 7 Days Target",
    badge: "Active Nodal Desk",
    badgeColor: "#059669",
    color: "#059669",
  },
  {
    id: "meesho",
    name: "Meesho",
    category: "E-Commerce",
    resolutionRate: "93.5%",
    avgDays: "3.4 Days",
    totalCases: 760,
    nodalEmail: "grievance-officer@meesho.com",
    rating: 4.5,
    authority: "Consumer Care Nodal Desk",
    sla: "48h Ack / 7 Days Target",
    badge: "Active Nodal Desk",
    badgeColor: "#64748b",
    color: "#64748b",
  },
  {
    id: "ajio",
    name: "Ajio (Reliance Retail)",
    category: "E-Commerce",
    resolutionRate: "94.1%",
    avgDays: "3.3 Days",
    totalCases: 510,
    nodalEmail: "grievance.officer@ajio.com",
    rating: 4.6,
    authority: "Reliance Retail Nodal Desk",
    sla: "48h Ack / 7 Days Target",
    badge: "Active Nodal Desk",
    badgeColor: "#059669",
    color: "#059669",
  },
  {
    id: "nykaa",
    name: "Nykaa",
    category: "E-Commerce",
    resolutionRate: "95.8%",
    avgDays: "2.6 Days",
    totalCases: 420,
    nodalEmail: "grievanceofficer@nykaa.com",
    rating: 4.7,
    authority: "Beauty & Lifestyle Grievance Desk",
    sla: "48h Ack / 7 Days Target",
    badge: "Active Nodal Desk",
    badgeColor: "#059669",
    color: "#059669",
  },
  {
    id: "tatacliq",
    name: "Tata CLiQ",
    category: "E-Commerce",
    resolutionRate: "95.0%",
    avgDays: "2.9 Days",
    totalCases: 380,
    nodalEmail: "grievanceofficer@tatacliq.com",
    rating: 4.6,
    authority: "Tata Digital Nodal Desk",
    sla: "48h Ack / 7 Days Target",
    badge: "Active Nodal Desk",
    badgeColor: "#2563eb",
    color: "#2563eb",
  },
  {
    id: "jiomart",
    name: "JioMart (Reliance)",
    category: "E-Commerce",
    resolutionRate: "93.0%",
    avgDays: "3.5 Days",
    totalCases: 490,
    nodalEmail: "grievanceofficer@jiomart.com",
    rating: 4.4,
    authority: "Reliance Retail Nodal Desk",
    sla: "48h Ack / 7 Days Target",
    badge: "Active Nodal Desk",
    badgeColor: "#1e40af",
    color: "#1e40af",
  },
  {
    id: "croma",
    name: "Croma Electronics",
    category: "E-Commerce",
    resolutionRate: "94.6%",
    avgDays: "3.1 Days",
    totalCases: 350,
    nodalEmail: "grievanceofficer@croma.com",
    rating: 4.6,
    authority: "Infiniti Retail Nodal Desk",
    sla: "48h Ack / 7 Days Target",
    badge: "Active Nodal Desk",
    badgeColor: "#059669",
    color: "#059669",
  },
  {
    id: "reliancedigital",
    name: "Reliance Digital",
    category: "E-Commerce",
    resolutionRate: "93.7%",
    avgDays: "3.4 Days",
    totalCases: 320,
    nodalEmail: "reliancedigital@ril.com",
    rating: 4.5,
    authority: "Reliance Retail Nodal Desk",
    sla: "48h Ack / 7 Days Target",
    badge: "Active Nodal Desk",
    badgeColor: "#1e40af",
    color: "#1e40af",
  },
  {
    id: "vijaysales",
    name: "Vijay Sales",
    category: "E-Commerce",
    resolutionRate: "92.9%",
    avgDays: "3.6 Days",
    totalCases: 260,
    nodalEmail: "support@vijaysales.com",
    rating: 4.4,
    authority: "Retail Support Desk",
    sla: "48h Ack / 7 Days Target",
    badge: "Active Nodal Desk",
    badgeColor: "#64748b",
    color: "#64748b",
  },
  {
    id: "lenskart",
    name: "Lenskart",
    category: "E-Commerce",
    resolutionRate: "96.1%",
    avgDays: "2.4 Days",
    totalCases: 410,
    nodalEmail: "grievance@lenskart.in",
    rating: 4.8,
    authority: "Eyewear Care Desk",
    sla: "48h Ack / 5 Days Target",
    badge: "Active Nodal Desk",
    badgeColor: "#059669",
    color: "#059669",
  },
  {
    id: "firstcry",
    name: "FirstCry",
    category: "E-Commerce",
    resolutionRate: "94.5%",
    avgDays: "3.0 Days",
    totalCases: 310,
    nodalEmail: "grievanceofficer@firstcry.com",
    rating: 4.6,
    authority: "Baby & Kids Care Desk",
    sla: "48h Ack / 7 Days Target",
    badge: "Active Nodal Desk",
    badgeColor: "#059669",
    color: "#059669",
  },
  {
    id: "snapdeal",
    name: "Snapdeal",
    category: "E-Commerce",
    resolutionRate: "91.8%",
    avgDays: "4.1 Days",
    totalCases: 290,
    nodalEmail: "grievanceofficer@snapdeal.com",
    rating: 4.3,
    authority: "E-Commerce Nodal Desk",
    sla: "48h Ack / 7 Days Target",
    badge: "Active Nodal Desk",
    badgeColor: "#64748b",
    color: "#64748b",
  },

  // ==========================================
  // 2. FOOD, DINING & GROCERY
  // ==========================================
  {
    id: "zomato",
    name: "Zomato",
    category: "Food & Grocery",
    resolutionRate: "97.6%",
    avgDays: "1.4 Days",
    totalCases: 1110,
    nodalEmail: "grievance@zomato.com",
    rating: 4.8,
    authority: "FSSAI Guidelines / Consumer Support",
    sla: "24h Ack / 3 Days Target",
    badge: "Active Nodal Desk",
    badgeColor: "#059669",
    color: "#059669",
  },
  {
    id: "swiggy",
    name: "Swiggy",
    category: "Food & Grocery",
    resolutionRate: "96.9%",
    avgDays: "1.6 Days",
    totalCases: 980,
    nodalEmail: "grievances@swiggy.in",
    rating: 4.7,
    authority: "FSSAI Guidelines / Consumer Support",
    sla: "24h Ack / 3 Days Target",
    badge: "Active Nodal Desk",
    badgeColor: "#059669",
    color: "#059669",
  },
  {
    id: "blinkit",
    name: "Blinkit",
    category: "Food & Grocery",
    resolutionRate: "97.1%",
    avgDays: "1.3 Days",
    totalCases: 620,
    nodalEmail: "grievance@blinkit.com",
    rating: 4.8,
    authority: "Quick Commerce Support Desk",
    sla: "24h Ack / 3 Days Target",
    badge: "Active Nodal Desk",
    badgeColor: "#059669",
    color: "#059669",
  },
  {
    id: "zepto",
    name: "Zepto",
    category: "Food & Grocery",
    resolutionRate: "96.5%",
    avgDays: "1.5 Days",
    totalCases: 540,
    nodalEmail: "grievance@zeptonow.com",
    rating: 4.7,
    authority: "Quick Commerce Support Desk",
    sla: "24h Ack / 3 Days Target",
    badge: "Active Nodal Desk",
    badgeColor: "#059669",
    color: "#059669",
  },
  {
    id: "bigbasket",
    name: "BigBasket",
    category: "Food & Grocery",
    resolutionRate: "95.9%",
    avgDays: "1.8 Days",
    totalCases: 480,
    nodalEmail: "grievance@bigbasket.com",
    rating: 4.7,
    authority: "Tata Enterprise Grocery Desk",
    sla: "24h Ack / 3 Days Target",
    badge: "Active Nodal Desk",
    badgeColor: "#059669",
    color: "#059669",
  },
  {
    id: "dominos",
    name: "Domino's Pizza India",
    category: "Food & Grocery",
    resolutionRate: "96.2%",
    avgDays: "1.5 Days",
    totalCases: 370,
    nodalEmail: "guestcare@jublfood.com",
    rating: 4.7,
    authority: "Jubilant FoodWorks Nodal Desk",
    sla: "24h Ack / 3 Days Target",
    badge: "Active Nodal Desk",
    badgeColor: "#059669",
    color: "#059669",
  },
  {
    id: "mcdonalds",
    name: "McDonald's India",
    category: "Food & Grocery",
    resolutionRate: "95.5%",
    avgDays: "1.7 Days",
    totalCases: 290,
    nodalEmail: "customerfeedback@mcdonaldsindia.com",
    rating: 4.6,
    authority: "Westlife / CPRL Care Desk",
    sla: "24h Ack / 3 Days Target",
    badge: "Active Nodal Desk",
    badgeColor: "#059669",
    color: "#059669",
  },
  {
    id: "kfc",
    name: "KFC India (Yum! Brands)",
    category: "Food & Grocery",
    resolutionRate: "94.8%",
    avgDays: "1.9 Days",
    totalCases: 240,
    nodalEmail: "feedback@kfc.com",
    rating: 4.5,
    authority: "Yum! Brands Redressal",
    sla: "24h Ack / 3 Days Target",
    badge: "Active Nodal Desk",
    badgeColor: "#64748b",
    color: "#64748b",
  },
  {
    id: "pizzahut",
    name: "Pizza Hut India",
    category: "Food & Grocery",
    resolutionRate: "94.2%",
    avgDays: "2.0 Days",
    totalCases: 210,
    nodalEmail: "feedback@pizzahut.co.in",
    rating: 4.5,
    authority: "Consumer Redressal Desk",
    sla: "24h Ack / 3 Days Target",
    badge: "Active Nodal Desk",
    badgeColor: "#64748b",
    color: "#64748b",
  },
  {
    id: "burgerking",
    name: "Burger King India",
    category: "Food & Grocery",
    resolutionRate: "95.0%",
    avgDays: "1.8 Days",
    totalCases: 190,
    nodalEmail: "customercare@burgerking.in",
    rating: 4.6,
    authority: "Restaurant Brands Asia Desk",
    sla: "24h Ack / 3 Days Target",
    badge: "Active Nodal Desk",
    badgeColor: "#059669",
    color: "#059669",
  },
  {
    id: "starbucks",
    name: "Tata Starbucks India",
    category: "Food & Grocery",
    resolutionRate: "97.0%",
    avgDays: "1.4 Days",
    totalCases: 180,
    nodalEmail: "customercare@tatastarbucks.com",
    rating: 4.9,
    authority: "Tata Starbucks Guest Relations",
    sla: "24h Ack / 3 Days Target",
    badge: "Active Nodal Desk",
    badgeColor: "#059669",
    color: "#059669",
  },

  // ==========================================
  // 3. BANKING, CARDS, UPI & FINTECH
  // ==========================================
  {
    id: "phonepe",
    name: "PhonePe (UPI & Payments)",
    category: "Banking & UPI",
    resolutionRate: "98.2%",
    avgDays: "1.9 Days",
    totalCases: 890,
    nodalEmail: "grievance-officer@phonepe.com",
    rating: 4.9,
    authority: "NPCI / RBI Ombudsman Scheme Guidelines",
    sla: "24h Ack / 5 Days Target",
    badge: "RBI Ombudsman Desk",
    badgeColor: "#0f766e",
    color: "#0f766e",
  },
  {
    id: "paytm",
    name: "Paytm Payments",
    category: "Banking & UPI",
    resolutionRate: "92.8%",
    avgDays: "3.1 Days",
    totalCases: 810,
    nodalEmail: "grievanceofficer@paytm.com",
    rating: 4.4,
    authority: "NPCI / RBI Ombudsman Scheme Guidelines",
    sla: "24h Ack / 5 Days Target",
    badge: "RBI Ombudsman Desk",
    badgeColor: "#0284c7",
    color: "#0284c7",
  },
  {
    id: "googlepay",
    name: "Google Pay India",
    category: "Banking & UPI",
    resolutionRate: "97.5%",
    avgDays: "1.8 Days",
    totalCases: 670,
    nodalEmail: "gpay-grievance-india@google.com",
    rating: 4.8,
    authority: "NPCI / Google India Ombudsman Desk",
    sla: "24h Ack / 5 Days Target",
    badge: "RBI Ombudsman Desk",
    badgeColor: "#059669",
    color: "#059669",
  },
  {
    id: "cred",
    name: "CRED",
    category: "Banking & UPI",
    resolutionRate: "96.4%",
    avgDays: "2.1 Days",
    totalCases: 410,
    nodalEmail: "grievance@cred.club",
    rating: 4.8,
    authority: "Fintech Nodal Grievance Desk",
    sla: "24h Ack / 5 Days Target",
    badge: "RBI Ombudsman Desk",
    badgeColor: "#0f766e",
    color: "#0f766e",
  },
  {
    id: "bharatpe",
    name: "BharatPe",
    category: "Banking & UPI",
    resolutionRate: "93.2%",
    avgDays: "3.0 Days",
    totalCases: 320,
    nodalEmail: "nodal@bharatpe.com",
    rating: 4.5,
    authority: "Merchant & Payment Ombudsman",
    sla: "24h Ack / 5 Days Target",
    badge: "RBI Ombudsman Desk",
    badgeColor: "#2563eb",
    color: "#2563eb",
  },
  {
    id: "sbi",
    name: "State Bank of India (SBI)",
    category: "Banking & UPI",
    resolutionRate: "89.5%",
    avgDays: "5.1 Days",
    totalCases: 2150,
    nodalEmail: "nodalofficer@sbi.co.in",
    rating: 4.3,
    authority: "RBI Customer Protection Guidelines",
    sla: "48h Ack / 7 Days Target",
    badge: "Statutory Banking Desk",
    badgeColor: "#1e40af",
    color: "#1e40af",
  },
  {
    id: "hdfc",
    name: "HDFC Bank",
    category: "Banking & UPI",
    resolutionRate: "93.1%",
    avgDays: "3.9 Days",
    totalCases: 940,
    nodalEmail: "grievance.redressal@hdfcbank.com",
    rating: 4.6,
    authority: "RBI Customer Protection Guidelines",
    sla: "48h Ack / 7 Days Target",
    badge: "Statutory Banking Desk",
    badgeColor: "#059669",
    color: "#059669",
  },
  {
    id: "icici",
    name: "ICICI Bank",
    category: "Banking & UPI",
    resolutionRate: "94.2%",
    avgDays: "3.6 Days",
    totalCases: 870,
    nodalEmail: "headservicequality@icicibank.com",
    rating: 4.7,
    authority: "RBI Customer Protection Guidelines",
    sla: "48h Ack / 7 Days Target",
    badge: "Statutory Banking Desk",
    badgeColor: "#059669",
    color: "#059669",
  },
  {
    id: "axis",
    name: "Axis Bank",
    category: "Banking & UPI",
    resolutionRate: "92.6%",
    avgDays: "4.1 Days",
    totalCases: 740,
    nodalEmail: "nodal.officer@axisbank.com",
    rating: 4.5,
    authority: "RBI Integrated Ombudsman Scheme",
    sla: "48h Ack / 7 Days Target",
    badge: "Statutory Banking Desk",
    badgeColor: "#2563eb",
    color: "#2563eb",
  },
  {
    id: "kotak",
    name: "Kotak Mahindra Bank",
    category: "Banking & UPI",
    resolutionRate: "93.8%",
    avgDays: "3.8 Days",
    totalCases: 610,
    nodalEmail: "nodalofficer@kotak.com",
    rating: 4.6,
    authority: "RBI Integrated Ombudsman Scheme",
    sla: "48h Ack / 7 Days Target",
    badge: "Statutory Banking Desk",
    badgeColor: "#059669",
    color: "#059669",
  },
  {
    id: "pnb",
    name: "Punjab National Bank (PNB)",
    category: "Banking & UPI",
    resolutionRate: "88.9%",
    avgDays: "5.4 Days",
    totalCases: 830,
    nodalEmail: "care@pnb.co.in",
    rating: 4.2,
    authority: "RBI Integrated Ombudsman Scheme",
    sla: "48h Ack / 7 Days Target",
    badge: "Statutory Banking Desk",
    badgeColor: "#1e40af",
    color: "#1e40af",
  },
  {
    id: "bankofbaroda",
    name: "Bank of Baroda",
    category: "Banking & UPI",
    resolutionRate: "90.1%",
    avgDays: "4.9 Days",
    totalCases: 690,
    nodalEmail: "gm.ops.ho@bankofbaroda.com",
    rating: 4.3,
    authority: "RBI Integrated Ombudsman Scheme",
    sla: "48h Ack / 7 Days Target",
    badge: "Statutory Banking Desk",
    badgeColor: "#1e40af",
    color: "#1e40af",
  },
  {
    id: "idfcfirst",
    name: "IDFC FIRST Bank",
    category: "Banking & UPI",
    resolutionRate: "95.1%",
    avgDays: "3.2 Days",
    totalCases: 460,
    nodalEmail: "nodalofficer@idfcfirstbank.com",
    rating: 4.7,
    authority: "RBI Integrated Ombudsman Scheme",
    sla: "48h Ack / 7 Days Target",
    badge: "Statutory Banking Desk",
    badgeColor: "#059669",
    color: "#059669",
  },
  {
    id: "zerodha",
    name: "Zerodha Broking",
    category: "Banking & UPI",
    resolutionRate: "96.8%",
    avgDays: "2.3 Days",
    totalCases: 520,
    nodalEmail: "complaints@zerodha.com",
    rating: 4.8,
    authority: "SEBI SCORES Regulatory Desk",
    sla: "24h Ack / 5 Days Target",
    badge: "SEBI SCORES Desk",
    badgeColor: "#0f766e",
    color: "#0f766e",
  },
  {
    id: "groww",
    name: "Groww",
    category: "Banking & UPI",
    resolutionRate: "95.7%",
    avgDays: "2.6 Days",
    totalCases: 480,
    nodalEmail: "grievance@groww.in",
    rating: 4.7,
    authority: "SEBI SCORES Regulatory Desk",
    sla: "24h Ack / 5 Days Target",
    badge: "SEBI SCORES Desk",
    badgeColor: "#0f766e",
    color: "#0f766e",
  },

  // ==========================================
  // 4. TELECOM & INTERNET
  // ==========================================
  {
    id: "jio",
    name: "Reliance Jio Infocomm",
    category: "Telecom",
    resolutionRate: "92.4%",
    avgDays: "4.2 Days",
    totalCases: 870,
    nodalEmail: "appellate.authority@jio.com",
    rating: 4.5,
    authority: "TRAI Telecom Directives",
    sla: "48h Ack / 7 Days Target",
    badge: "TRAI Appellate Desk",
    badgeColor: "#1e40af",
    color: "#1e40af",
  },
  {
    id: "airtel",
    name: "Bharti Airtel",
    category: "Telecom",
    resolutionRate: "91.8%",
    avgDays: "4.5 Days",
    totalCases: 820,
    nodalEmail: "nodalofficer.india@airtel.com",
    rating: 4.4,
    authority: "TRAI Telecom Directives",
    sla: "48h Ack / 7 Days Target",
    badge: "TRAI Appellate Desk",
    badgeColor: "#1e40af",
    color: "#1e40af",
  },
  {
    id: "vi",
    name: "Vodafone Idea (Vi)",
    category: "Telecom",
    resolutionRate: "89.4%",
    avgDays: "4.8 Days",
    totalCases: 560,
    nodalEmail: "nodalofficer@vodafoneidea.com",
    rating: 4.2,
    authority: "TRAI Telecom Directives",
    sla: "48h Ack / 7 Days Target",
    badge: "TRAI Appellate Desk",
    badgeColor: "#2563eb",
    color: "#2563eb",
  },
  {
    id: "bsnl",
    name: "BSNL India",
    category: "Telecom",
    resolutionRate: "86.1%",
    avgDays: "6.2 Days",
    totalCases: 620,
    nodalEmail: "cmdbsnl@bsnl.co.in",
    rating: 4.0,
    authority: "DOT / CPGRAMS Portal",
    sla: "48h Ack / 7 Days Target",
    badge: "Public Sector Desk",
    badgeColor: "#1e40af",
    color: "#1e40af",
  },
  {
    id: "actfibernet",
    name: "ACT Fibernet",
    category: "Telecom",
    resolutionRate: "94.2%",
    avgDays: "2.8 Days",
    totalCases: 340,
    nodalEmail: "nodal@actcorp.in",
    rating: 4.6,
    authority: "Broadband Redressal Channel",
    sla: "48h Ack / 5 Days Target",
    badge: "Active Nodal Desk",
    badgeColor: "#059669",
    color: "#059669",
  },

  // ==========================================
  // 5. TRAVEL, AIRLINES, RAILWAYS & MOBILITY
  // ==========================================
  {
    id: "makemytrip",
    name: "MakeMyTrip",
    category: "Travel & Mobility",
    resolutionRate: "93.7%",
    avgDays: "3.5 Days",
    totalCases: 640,
    nodalEmail: "grievance.officer@makemytrip.com",
    rating: 4.6,
    authority: "Travel & Hospitality Nodal Desk",
    sla: "24h Ack / 7 Days Target",
    badge: "Active Nodal Desk",
    badgeColor: "#2563eb",
    color: "#2563eb",
  },
  {
    id: "irctc",
    name: "IRCTC (Indian Railways)",
    category: "Travel & Mobility",
    resolutionRate: "90.2%",
    avgDays: "4.8 Days",
    totalCases: 1150,
    nodalEmail: "customercare@irctc.co.in",
    rating: 4.3,
    authority: "Railways Redressal Channel (RailMadad)",
    sla: "24h Ack / 5 Days Target",
    badge: "Public Sector Desk",
    badgeColor: "#0f766e",
    color: "#0f766e",
  },
  {
    id: "indigo",
    name: "IndiGo Airlines",
    category: "Travel & Mobility",
    resolutionRate: "94.6%",
    avgDays: "3.2 Days",
    totalCases: 710,
    nodalEmail: "nodalofficer@goindigo.in",
    rating: 4.6,
    authority: "AirSewa / DGCA Passenger Redressal",
    sla: "24h Ack / 7 Days Target",
    badge: "Aviation Nodal Desk",
    badgeColor: "#1e40af",
    color: "#1e40af",
  },
  {
    id: "airindia",
    name: "Air India",
    category: "Travel & Mobility",
    resolutionRate: "91.5%",
    avgDays: "4.4 Days",
    totalCases: 680,
    nodalEmail: "nodalofficer@airindia.com",
    rating: 4.4,
    authority: "AirSewa / DGCA Passenger Redressal",
    sla: "24h Ack / 7 Days Target",
    badge: "Aviation Nodal Desk",
    badgeColor: "#1e40af",
    color: "#1e40af",
  },
  {
    id: "spicejet",
    name: "SpiceJet Airlines",
    category: "Travel & Mobility",
    resolutionRate: "87.3%",
    avgDays: "5.8 Days",
    totalCases: 540,
    nodalEmail: "nodalofficer@spicejet.com",
    rating: 4.0,
    authority: "AirSewa / DGCA Passenger Redressal",
    sla: "24h Ack / 7 Days Target",
    badge: "Aviation Nodal Desk",
    badgeColor: "#dc2626",
    color: "#dc2626",
  },
  {
    id: "akasaair",
    name: "Akasa Air",
    category: "Travel & Mobility",
    resolutionRate: "95.8%",
    avgDays: "2.7 Days",
    totalCases: 320,
    nodalEmail: "nodalofficer@akasaair.com",
    rating: 4.7,
    authority: "AirSewa / DGCA Passenger Redressal",
    sla: "24h Ack / 7 Days Target",
    badge: "Aviation Nodal Desk",
    badgeColor: "#059669",
    color: "#059669",
  },
  {
    id: "uber",
    name: "Uber India",
    category: "Travel & Mobility",
    resolutionRate: "94.5%",
    avgDays: "2.1 Days",
    totalCases: 710,
    nodalEmail: "grievance-officer-india@uber.com",
    rating: 4.6,
    authority: "Mobility Grievance Desk",
    sla: "24h Ack / 5 Days Target",
    badge: "Active Nodal Desk",
    badgeColor: "#64748b",
    color: "#64748b",
  },
  {
    id: "ola",
    name: "Ola Cabs",
    category: "Travel & Mobility",
    resolutionRate: "90.8%",
    avgDays: "3.9 Days",
    totalCases: 840,
    nodalEmail: "grievanceofficer@olacabs.com",
    rating: 4.3,
    authority: "Mobility Grievance Desk",
    sla: "24h Ack / 5 Days Target",
    badge: "Active Nodal Desk",
    badgeColor: "#64748b",
    color: "#64748b",
  },
  {
    id: "rapido",
    name: "Rapido Bike Taxi",
    category: "Travel & Mobility",
    resolutionRate: "93.9%",
    avgDays: "2.4 Days",
    totalCases: 490,
    nodalEmail: "grievance@rapido.bike",
    rating: 4.6,
    authority: "Mobility Grievance Desk",
    sla: "24h Ack / 5 Days Target",
    badge: "Active Nodal Desk",
    badgeColor: "#059669",
    color: "#059669",
  },
  {
    id: "easemytrip",
    name: "EaseMyTrip",
    category: "Travel & Mobility",
    resolutionRate: "94.0%",
    avgDays: "3.1 Days",
    totalCases: 370,
    nodalEmail: "care@easemytrip.com",
    rating: 4.6,
    authority: "Travel Booking Desk",
    sla: "24h Ack / 5 Days Target",
    badge: "Active Nodal Desk",
    badgeColor: "#2563eb",
    color: "#2563eb",
  },
  {
    id: "cleartrip",
    name: "Cleartrip (Flipkart Group)",
    category: "Travel & Mobility",
    resolutionRate: "94.4%",
    avgDays: "2.9 Days",
    totalCases: 340,
    nodalEmail: "grievance@cleartrip.com",
    rating: 4.6,
    authority: "Travel Booking Desk",
    sla: "24h Ack / 5 Days Target",
    badge: "Active Nodal Desk",
    badgeColor: "#059669",
    color: "#059669",
  },
  {
    id: "oyo",
    name: "OYO Rooms",
    category: "Travel & Mobility",
    resolutionRate: "91.2%",
    avgDays: "3.7 Days",
    totalCases: 610,
    nodalEmail: "grievanceofficer@oyorooms.com",
    rating: 4.3,
    authority: "Hospitality Grievance Desk",
    sla: "24h Ack / 5 Days Target",
    badge: "Active Nodal Desk",
    badgeColor: "#64748b",
    color: "#64748b",
  },

  // ==========================================
  // 6. ELECTRONICS, SMARTPHONES & COMPUTERS
  // ==========================================
  {
    id: "samsung",
    name: "Samsung Electronics India",
    category: "Electronics & Tech",
    resolutionRate: "95.0%",
    avgDays: "3.7 Days",
    totalCases: 590,
    nodalEmail: "grievance.india@samsung.com",
    rating: 4.7,
    authority: "Electronics Care Support",
    sla: "48h Ack / 7 Days Target",
    badge: "Hardware Nodal Desk",
    badgeColor: "#2563eb",
    color: "#2563eb",
  },
  {
    id: "apple",
    name: "Apple India",
    category: "Electronics & Tech",
    resolutionRate: "96.8%",
    avgDays: "2.5 Days",
    totalCases: 480,
    nodalEmail: "india_grievance_officer@apple.com",
    rating: 4.9,
    authority: "Apple Customer Relations",
    sla: "48h Ack / 7 Days Target",
    badge: "Hardware Nodal Desk",
    badgeColor: "#64748b",
    color: "#64748b",
  },
  {
    id: "xiaomi",
    name: "Xiaomi / Redmi India",
    category: "Electronics & Tech",
    resolutionRate: "93.4%",
    avgDays: "3.8 Days",
    totalCases: 520,
    nodalEmail: "grievance-officer@xiaomi.com",
    rating: 4.5,
    authority: "Mi Customer Care Nodal Desk",
    sla: "48h Ack / 7 Days Target",
    badge: "Hardware Nodal Desk",
    badgeColor: "#f97316",
    color: "#f97316",
  },
  {
    id: "oneplus",
    name: "OnePlus India",
    category: "Electronics & Tech",
    resolutionRate: "94.3%",
    avgDays: "3.4 Days",
    totalCases: 430,
    nodalEmail: "grievance.officer@oneplus.com",
    rating: 4.6,
    authority: "OnePlus Care Support Desk",
    sla: "48h Ack / 7 Days Target",
    badge: "Hardware Nodal Desk",
    badgeColor: "#dc2626",
    color: "#dc2626",
  },
  {
    id: "realme",
    name: "Realme India",
    category: "Electronics & Tech",
    resolutionRate: "93.1%",
    avgDays: "3.9 Days",
    totalCases: 380,
    nodalEmail: "grievance@realme.com",
    rating: 4.5,
    authority: "Realme Customer Care",
    sla: "48h Ack / 7 Days Target",
    badge: "Hardware Nodal Desk",
    badgeColor: "#eab308",
    color: "#eab308",
  },
  {
    id: "vivo",
    name: "Vivo India",
    category: "Electronics & Tech",
    resolutionRate: "93.8%",
    avgDays: "3.6 Days",
    totalCases: 360,
    nodalEmail: "grievance@vivo.com",
    rating: 4.6,
    authority: "Vivo Customer Care",
    sla: "48h Ack / 7 Days Target",
    badge: "Hardware Nodal Desk",
    badgeColor: "#0284c7",
    color: "#0284c7",
  },
  {
    id: "oppo",
    name: "Oppo India",
    category: "Electronics & Tech",
    resolutionRate: "93.5%",
    avgDays: "3.7 Days",
    totalCases: 340,
    nodalEmail: "grievance@oppo.com",
    rating: 4.5,
    authority: "Oppo Customer Care",
    sla: "48h Ack / 7 Days Target",
    badge: "Hardware Nodal Desk",
    badgeColor: "#059669",
    color: "#059669",
  },
  {
    id: "sony",
    name: "Sony India",
    category: "Electronics & Tech",
    resolutionRate: "95.6%",
    avgDays: "3.0 Days",
    totalCases: 320,
    nodalEmail: "sonyindia.care@sony.com",
    rating: 4.8,
    authority: "Sony Customer Care Desk",
    sla: "48h Ack / 7 Days Target",
    badge: "Hardware Nodal Desk",
    badgeColor: "#000000",
    color: "#000000",
  },
  {
    id: "hp",
    name: "HP India (Hewlett Packard)",
    category: "Electronics & Tech",
    resolutionRate: "94.8%",
    avgDays: "3.3 Days",
    totalCases: 390,
    nodalEmail: "in.contact@hp.com",
    rating: 4.7,
    authority: "HP India Customer Relations",
    sla: "48h Ack / 7 Days Target",
    badge: "Hardware Nodal Desk",
    badgeColor: "#0284c7",
    color: "#0284c7",
  },
  {
    id: "dell",
    name: "Dell Technologies India",
    category: "Electronics & Tech",
    resolutionRate: "95.2%",
    avgDays: "3.1 Days",
    totalCases: 370,
    nodalEmail: "india_customer_care@dell.com",
    rating: 4.7,
    authority: "Dell Customer Care Desk",
    sla: "48h Ack / 7 Days Target",
    badge: "Hardware Nodal Desk",
    badgeColor: "#0284c7",
    color: "#0284c7",
  },
  {
    id: "lenovo",
    name: "Lenovo India",
    category: "Electronics & Tech",
    resolutionRate: "93.9%",
    avgDays: "3.5 Days",
    totalCases: 350,
    nodalEmail: "grievance@lenovo.com",
    rating: 4.6,
    authority: "Lenovo Customer Care Desk",
    sla: "48h Ack / 7 Days Target",
    badge: "Hardware Nodal Desk",
    badgeColor: "#dc2626",
    color: "#dc2626",
  },
  {
    id: "asus",
    name: "Asus India",
    category: "Electronics & Tech",
    resolutionRate: "94.0%",
    avgDays: "3.4 Days",
    totalCases: 290,
    nodalEmail: "support_india@asus.com",
    rating: 4.6,
    authority: "Asus Customer Care Desk",
    sla: "48h Ack / 7 Days Target",
    badge: "Hardware Nodal Desk",
    badgeColor: "#2563eb",
    color: "#2563eb",
  },
  {
    id: "boat",
    name: "boAt Lifestyle",
    category: "Electronics & Tech",
    resolutionRate: "96.0%",
    avgDays: "2.5 Days",
    totalCases: 460,
    nodalEmail: "nodalofficer@imaginemarketingindia.com",
    rating: 4.7,
    authority: "Imagine Marketing Audio Desk",
    sla: "48h Ack / 5 Days Target",
    badge: "Active Nodal Desk",
    badgeColor: "#dc2626",
    color: "#dc2626",
  },
  {
    id: "noise",
    name: "Noise (Nexxbase)",
    category: "Electronics & Tech",
    resolutionRate: "95.5%",
    avgDays: "2.7 Days",
    totalCases: 370,
    nodalEmail: "grievance@gonoise.com",
    rating: 4.7,
    authority: "Smart Wearables Care Desk",
    sla: "48h Ack / 5 Days Target",
    badge: "Active Nodal Desk",
    badgeColor: "#059669",
    color: "#059669",
  },

  // ==========================================
  // 7. HOME APPLIANCES & DURABLES
  // ==========================================
  {
    id: "lg",
    name: "LG Electronics India",
    category: "Home Appliances",
    resolutionRate: "95.4%",
    avgDays: "3.2 Days",
    totalCases: 470,
    nodalEmail: "serviceindia@lge.com",
    rating: 4.7,
    authority: "LG Consumer Care Services",
    sla: "48h Ack / 7 Days Target",
    badge: "Hardware Nodal Desk",
    badgeColor: "#db2777",
    color: "#db2777",
  },
  {
    id: "whirlpool",
    name: "Whirlpool of India",
    category: "Home Appliances",
    resolutionRate: "93.8%",
    avgDays: "3.7 Days",
    totalCases: 340,
    nodalEmail: "grievanceofficer@whirlpool.com",
    rating: 4.5,
    authority: "Whirlpool Consumer Services",
    sla: "48h Ack / 7 Days Target",
    badge: "Hardware Nodal Desk",
    badgeColor: "#2563eb",
    color: "#2563eb",
  },
  {
    id: "voltas",
    name: "Voltas (Tata Enterprise)",
    category: "Home Appliances",
    resolutionRate: "94.5%",
    avgDays: "3.4 Days",
    totalCases: 390,
    nodalEmail: "nodalofficer@voltas.com",
    rating: 4.6,
    authority: "Tata Voltas Care Desk",
    sla: "48h Ack / 7 Days Target",
    badge: "Hardware Nodal Desk",
    badgeColor: "#0284c7",
    color: "#0284c7",
  },
  {
    id: "havells",
    name: "Havells India (Lloyd)",
    category: "Home Appliances",
    resolutionRate: "94.8%",
    avgDays: "3.3 Days",
    totalCases: 360,
    nodalEmail: "grievance@havells.com",
    rating: 4.6,
    authority: "Havells Consumer Care",
    sla: "48h Ack / 7 Days Target",
    badge: "Hardware Nodal Desk",
    badgeColor: "#dc2626",
    color: "#dc2626",
  },
  {
    id: "godrej",
    name: "Godrej Appliances",
    category: "Home Appliances",
    resolutionRate: "94.0%",
    avgDays: "3.5 Days",
    totalCases: 310,
    nodalEmail: "smartcare@godrej.com",
    rating: 4.6,
    authority: "Godrej Smart Care Desk",
    sla: "48h Ack / 7 Days Target",
    badge: "Hardware Nodal Desk",
    badgeColor: "#059669",
    color: "#059669",
  },
  {
    id: "bosch",
    name: "Bosch Home Appliances",
    category: "Home Appliances",
    resolutionRate: "95.2%",
    avgDays: "3.0 Days",
    totalCases: 280,
    nodalEmail: "service.in@bosch.com",
    rating: 4.8,
    authority: "BSH Home Appliances Desk",
    sla: "48h Ack / 7 Days Target",
    badge: "Hardware Nodal Desk",
    badgeColor: "#dc2626",
    color: "#dc2626",
  },
  {
    id: "eurekaforbes",
    name: "Eureka Forbes (Aquaguard)",
    category: "Home Appliances",
    resolutionRate: "94.1%",
    avgDays: "3.2 Days",
    totalCases: 330,
    nodalEmail: "customercare@eurekaforbes.com",
    rating: 4.6,
    authority: "Aquaguard Water Care Desk",
    sla: "48h Ack / 5 Days Target",
    badge: "Active Nodal Desk",
    badgeColor: "#0284c7",
    color: "#0284c7",
  },

  // ==========================================
  // 8. AUTOMOBILE, TWO-WHEELERS & EV
  // ==========================================
  {
    id: "tatamotors",
    name: "Tata Motors Passenger Vehicles",
    category: "Automotive & EV",
    resolutionRate: "93.5%",
    avgDays: "4.5 Days",
    totalCases: 580,
    nodalEmail: "nodalofficer@tatamotors.com",
    rating: 4.5,
    authority: "Tata Motors Consumer Redressal",
    sla: "48h Ack / 7 Days Target",
    badge: "Automotive Nodal Desk",
    badgeColor: "#1e40af",
    color: "#1e40af",
  },
  {
    id: "marutisuzuki",
    name: "Maruti Suzuki India",
    category: "Automotive & EV",
    resolutionRate: "94.8%",
    avgDays: "3.8 Days",
    totalCases: 650,
    nodalEmail: "nodal@maruti.co.in",
    rating: 4.7,
    authority: "Maruti Suzuki Customer Care",
    sla: "48h Ack / 7 Days Target",
    badge: "Automotive Nodal Desk",
    badgeColor: "#2563eb",
    color: "#2563eb",
  },
  {
    id: "hyundai",
    name: "Hyundai Motor India",
    category: "Automotive & EV",
    resolutionRate: "94.2%",
    avgDays: "4.0 Days",
    totalCases: 490,
    nodalEmail: "nodalofficer@hmil.net",
    rating: 4.6,
    authority: "Hyundai Consumer Redressal",
    sla: "48h Ack / 7 Days Target",
    badge: "Automotive Nodal Desk",
    badgeColor: "#1e40af",
    color: "#1e40af",
  },
  {
    id: "mahindra",
    name: "Mahindra & Mahindra",
    category: "Automotive & EV",
    resolutionRate: "93.0%",
    avgDays: "4.6 Days",
    totalCases: 460,
    nodalEmail: "customercare@mahindra.com",
    rating: 4.5,
    authority: "Mahindra Automotive Desk",
    sla: "48h Ack / 7 Days Target",
    badge: "Automotive Nodal Desk",
    badgeColor: "#dc2626",
    color: "#dc2626",
  },
  {
    id: "olaelectric",
    name: "Ola Electric Mobility",
    category: "Automotive & EV",
    resolutionRate: "88.6%",
    avgDays: "5.5 Days",
    totalCases: 780,
    nodalEmail: "nodal@olaelectric.com",
    rating: 4.1,
    authority: "Central Consumer Protection Authority (CCPA)",
    sla: "24h Ack / 7 Days Target",
    badge: "EV Redressal Desk",
    badgeColor: "#eab308",
    color: "#eab308",
  },
  {
    id: "ather",
    name: "Ather Energy",
    category: "Automotive & EV",
    resolutionRate: "95.4%",
    avgDays: "3.1 Days",
    totalCases: 340,
    nodalEmail: "grievance@atherenergy.com",
    rating: 4.8,
    authority: "Ather EV Care Desk",
    sla: "48h Ack / 7 Days Target",
    badge: "Active Nodal Desk",
    badgeColor: "#059669",
    color: "#059669",
  },
  {
    id: "tvsmotor",
    name: "TVS Motor Company",
    category: "Automotive & EV",
    resolutionRate: "93.8%",
    avgDays: "3.9 Days",
    totalCases: 390,
    nodalEmail: "customercare@tvsmotor.com",
    rating: 4.6,
    authority: "TVS Consumer Care Desk",
    sla: "48h Ack / 7 Days Target",
    badge: "Automotive Nodal Desk",
    badgeColor: "#2563eb",
    color: "#2563eb",
  },
  {
    id: "heromotocorp",
    name: "Hero MotoCorp",
    category: "Automotive & EV",
    resolutionRate: "93.2%",
    avgDays: "4.1 Days",
    totalCases: 410,
    nodalEmail: "customercare@heromotocorp.com",
    rating: 4.5,
    authority: "Hero MotoCorp Customer Care",
    sla: "48h Ack / 7 Days Target",
    badge: "Automotive Nodal Desk",
    badgeColor: "#dc2626",
    color: "#dc2626",
  },
  {
    id: "royalenfield",
    name: "Royal Enfield",
    category: "Automotive & EV",
    resolutionRate: "94.6%",
    avgDays: "3.5 Days",
    totalCases: 380,
    nodalEmail: "support@royalenfield.com",
    rating: 4.7,
    authority: "Eicher Motors Support Desk",
    sla: "48h Ack / 7 Days Target",
    badge: "Automotive Nodal Desk",
    badgeColor: "#000000",
    color: "#000000",
  },

  // ==========================================
  // 9. INSURANCE, HEALTH & PHARMACY
  // ==========================================
  {
    id: "lic",
    name: "Life Insurance Corporation (LIC)",
    category: "Insurance & Health",
    resolutionRate: "89.2%",
    avgDays: "6.8 Days",
    totalCases: 950,
    nodalEmail: "co_crmgrv@licindia.com",
    rating: 4.3,
    authority: "IRDAI Bima Bharosa Scheme",
    sla: "48h Ack / 14 Days Target",
    badge: "IRDAI Ombudsman Desk",
    badgeColor: "#1e40af",
    color: "#1e40af",
  },
  {
    id: "starhealth",
    name: "Star Health Insurance",
    category: "Insurance & Health",
    resolutionRate: "91.8%",
    avgDays: "4.9 Days",
    totalCases: 680,
    nodalEmail: "gro@starhealth.in",
    rating: 4.4,
    authority: "IRDAI Insurance Ombudsman",
    sla: "48h Ack / 7 Days Target",
    badge: "IRDAI Ombudsman Desk",
    badgeColor: "#2563eb",
    color: "#2563eb",
  },
  {
    id: "hdfcergo",
    name: "HDFC ERGO General Insurance",
    category: "Insurance & Health",
    resolutionRate: "94.5%",
    avgDays: "3.8 Days",
    totalCases: 510,
    nodalEmail: "grievance@hdfcergo.com",
    rating: 4.7,
    authority: "IRDAI Insurance Ombudsman",
    sla: "48h Ack / 7 Days Target",
    badge: "IRDAI Ombudsman Desk",
    badgeColor: "#059669",
    color: "#059669",
  },
  {
    id: "icicilombard",
    name: "ICICI Lombard Insurance",
    category: "Insurance & Health",
    resolutionRate: "94.1%",
    avgDays: "3.9 Days",
    totalCases: 480,
    nodalEmail: "grievanceredressal@icicilombard.com",
    rating: 4.7,
    authority: "IRDAI Insurance Ombudsman",
    sla: "48h Ack / 7 Days Target",
    badge: "IRDAI Ombudsman Desk",
    badgeColor: "#059669",
    color: "#059669",
  },
  {
    id: "policybazaar",
    name: "PolicyBazaar",
    category: "Insurance & Health",
    resolutionRate: "95.6%",
    avgDays: "2.6 Days",
    totalCases: 420,
    nodalEmail: "grievance@policybazaar.com",
    rating: 4.8,
    authority: "Insurance Facilitation Desk",
    sla: "24h Ack / 5 Days Target",
    badge: "Active Nodal Desk",
    badgeColor: "#059669",
    color: "#059669",
  },
  {
    id: "tata1mg",
    name: "Tata 1mg",
    category: "Insurance & Health",
    resolutionRate: "96.4%",
    avgDays: "1.9 Days",
    totalCases: 490,
    nodalEmail: "grievance@1mg.com",
    rating: 4.8,
    authority: "E-Pharmacy Care Desk",
    sla: "24h Ack / 3 Days Target",
    badge: "Active Nodal Desk",
    badgeColor: "#059669",
    color: "#059669",
  },
  {
    id: "apollo247",
    name: "Apollo 24|7",
    category: "Insurance & Health",
    resolutionRate: "96.0%",
    avgDays: "2.1 Days",
    totalCases: 430,
    nodalEmail: "helpdesk@apollo247.com",
    rating: 4.8,
    authority: "Apollo Healthcare Redressal",
    sla: "24h Ack / 3 Days Target",
    badge: "Active Nodal Desk",
    badgeColor: "#059669",
    color: "#059669",
  },
  {
    id: "pharmeasy",
    name: "PharmEasy",
    category: "Insurance & Health",
    resolutionRate: "94.8%",
    avgDays: "2.5 Days",
    totalCases: 370,
    nodalEmail: "care@pharmeasy.in",
    rating: 4.6,
    authority: "E-Pharmacy Care Desk",
    sla: "24h Ack / 3 Days Target",
    badge: "Active Nodal Desk",
    badgeColor: "#0284c7",
    color: "#0284c7",
  },

  // ==========================================
  // 10. OTT, STREAMING & MEDIA
  // ==========================================
  {
    id: "netflix",
    name: "Netflix India",
    category: "OTT & Media",
    resolutionRate: "97.4%",
    avgDays: "1.7 Days",
    totalCases: 380,
    nodalEmail: "grievance-officer-india@netflix.com",
    rating: 4.9,
    authority: "Digital Media Ethics Code / I&B Ministry",
    sla: "24h Ack / 5 Days Target",
    badge: "Digital Ethics Desk",
    badgeColor: "#dc2626",
    color: "#dc2626",
  },
  {
    id: "hotstar",
    name: "Disney+ Hotstar / JioHotstar",
    category: "OTT & Media",
    resolutionRate: "96.2%",
    avgDays: "2.1 Days",
    totalCases: 450,
    nodalEmail: "grievanceofficer@hotstar.com",
    rating: 4.7,
    authority: "Digital Media Ethics Code / I&B Ministry",
    sla: "24h Ack / 5 Days Target",
    badge: "Digital Ethics Desk",
    badgeColor: "#1e40af",
    color: "#1e40af",
  },
  {
    id: "primevideo",
    name: "Amazon Prime Video",
    category: "OTT & Media",
    resolutionRate: "96.8%",
    avgDays: "1.9 Days",
    totalCases: 390,
    nodalEmail: "grievanceofficer-primevideo@amazon.com",
    rating: 4.8,
    authority: "Digital Media Ethics Code / I&B Ministry",
    sla: "24h Ack / 5 Days Target",
    badge: "Digital Ethics Desk",
    badgeColor: "#0284c7",
    color: "#0284c7",
  },
  {
    id: "bookmyshow",
    name: "BookMyShow",
    category: "OTT & Media",
    resolutionRate: "96.5%",
    avgDays: "1.6 Days",
    totalCases: 420,
    nodalEmail: "grievance@bookmyshow.com",
    rating: 4.8,
    authority: "Ticketing & Entertainment Desk",
    sla: "24h Ack / 3 Days Target",
    badge: "Active Nodal Desk",
    badgeColor: "#dc2626",
    color: "#dc2626",
  },
  {
    id: "spotify",
    name: "Spotify India",
    category: "OTT & Media",
    resolutionRate: "97.1%",
    avgDays: "1.5 Days",
    totalCases: 290,
    nodalEmail: "grievance-india@spotify.com",
    rating: 4.9,
    authority: "Streaming Support Desk",
    sla: "24h Ack / 5 Days Target",
    badge: "Active Nodal Desk",
    badgeColor: "#059669",
    color: "#059669",
  },

  // ==========================================
  // 11. LOGISTICS & COURIERS
  // ==========================================
  {
    id: "delhivery",
    name: "Delhivery Logistics",
    category: "Logistics & Postal",
    resolutionRate: "94.6%",
    avgDays: "2.8 Days",
    totalCases: 620,
    nodalEmail: "nodalofficer@delhivery.com",
    rating: 4.6,
    authority: "Supply Chain Grievance Desk",
    sla: "24h Ack / 5 Days Target",
    badge: "Active Nodal Desk",
    badgeColor: "#059669",
    color: "#059669",
  },
  {
    id: "bluedart",
    name: "Blue Dart Express (DHL)",
    category: "Logistics & Postal",
    resolutionRate: "95.8%",
    avgDays: "2.4 Days",
    totalCases: 540,
    nodalEmail: "nodal@bluedart.com",
    rating: 4.8,
    authority: "DHL Express Support Desk",
    sla: "24h Ack / 5 Days Target",
    badge: "Active Nodal Desk",
    badgeColor: "#2563eb",
    color: "#2563eb",
  },
  {
    id: "dtdc",
    name: "DTDC Express",
    category: "Logistics & Postal",
    resolutionRate: "93.4%",
    avgDays: "3.2 Days",
    totalCases: 430,
    nodalEmail: "grievance@dtdc.com",
    rating: 4.5,
    authority: "Courier Services Redressal",
    sla: "24h Ack / 5 Days Target",
    badge: "Active Nodal Desk",
    badgeColor: "#dc2626",
    color: "#dc2626",
  },
  {
    id: "indiapost",
    name: "India Post (Speed Post)",
    category: "Logistics & Postal",
    resolutionRate: "89.8%",
    avgDays: "5.2 Days",
    totalCases: 890,
    nodalEmail: "complaints@indiapost.gov.in",
    rating: 4.3,
    authority: "CPGRAMS / Department of Posts",
    sla: "48h Ack / 7 Days Target",
    badge: "Public Sector Desk",
    badgeColor: "#dc2626",
    color: "#dc2626",
  },
  {
    id: "shadowfax",
    name: "Shadowfax",
    category: "Logistics & Postal",
    resolutionRate: "94.2%",
    avgDays: "2.9 Days",
    totalCases: 360,
    nodalEmail: "grievance@shadowfax.in",
    rating: 4.6,
    authority: "Hyperlocal Logistics Desk",
    sla: "24h Ack / 5 Days Target",
    badge: "Active Nodal Desk",
    badgeColor: "#059669",
    color: "#059669",
  },

  // ==========================================
  // 12. ED-TECH & ONLINE EDUCATION
  // ==========================================
  {
    id: "byjus",
    name: "BYJU'S (Think & Learn)",
    category: "EdTech & Education",
    resolutionRate: "84.2%",
    avgDays: "6.9 Days",
    totalCases: 890,
    nodalEmail: "grievance@byjus.com",
    rating: 3.9,
    authority: "NCDRC / Consumer Protection Authority",
    sla: "24h Ack / 7 Days Target",
    badge: "Active Petition Desk",
    badgeColor: "#dc2626",
    color: "#dc2626",
  },
  {
    id: "unacademy",
    name: "Unacademy",
    category: "EdTech & Education",
    resolutionRate: "93.4%",
    avgDays: "3.5 Days",
    totalCases: 410,
    nodalEmail: "grievance@unacademy.com",
    rating: 4.5,
    authority: "EdTech Redressal Channel",
    sla: "24h Ack / 7 Days Target",
    badge: "Active Nodal Desk",
    badgeColor: "#2563eb",
    color: "#2563eb",
  },
  {
    id: "physicswallah",
    name: "Physics Wallah (PW)",
    category: "EdTech & Education",
    resolutionRate: "96.2%",
    avgDays: "2.3 Days",
    totalCases: 470,
    nodalEmail: "grievance@pw.live",
    rating: 4.8,
    authority: "Student Care Support Desk",
    sla: "24h Ack / 5 Days Target",
    badge: "Active Nodal Desk",
    badgeColor: "#059669",
    color: "#059669",
  },
  {
    id: "upgrad",
    name: "upGrad Education",
    category: "EdTech & Education",
    resolutionRate: "92.8%",
    avgDays: "3.8 Days",
    totalCases: 320,
    nodalEmail: "grievance@upgrad.com",
    rating: 4.5,
    authority: "Higher Ed Support Desk",
    sla: "24h Ack / 7 Days Target",
    badge: "Active Nodal Desk",
    badgeColor: "#2563eb",
    color: "#2563eb",
  },

  // ==========================================
  // 13. REAL ESTATE & HOUSING DEVELOPERS
  // ==========================================
  {
    id: "dlf",
    name: "DLF Limited",
    category: "Real Estate",
    resolutionRate: "90.4%",
    avgDays: "7.2 Days",
    totalCases: 380,
    nodalEmail: "nodalofficer@dlf.in",
    rating: 4.4,
    authority: "RERA Real Estate Regulatory Authority",
    sla: "48h Ack / 14 Days Target",
    badge: "RERA Nodal Desk",
    badgeColor: "#1e40af",
    color: "#1e40af",
  },
  {
    id: "godrejproperties",
    name: "Godrej Properties",
    category: "Real Estate",
    resolutionRate: "92.8%",
    avgDays: "6.1 Days",
    totalCases: 340,
    nodalEmail: "customercare@godrejproperties.com",
    rating: 4.6,
    authority: "RERA Real Estate Regulatory Authority",
    sla: "48h Ack / 14 Days Target",
    badge: "RERA Nodal Desk",
    badgeColor: "#059669",
    color: "#059669",
  },
  {
    id: "lodha",
    name: "Macrotech Developers (Lodha)",
    category: "Real Estate",
    resolutionRate: "91.2%",
    avgDays: "6.5 Days",
    totalCases: 310,
    nodalEmail: "customercare@lodhagroup.com",
    rating: 4.5,
    authority: "RERA Real Estate Regulatory Authority",
    sla: "48h Ack / 14 Days Target",
    badge: "RERA Nodal Desk",
    badgeColor: "#2563eb",
    color: "#2563eb",
  },
  {
    id: "prestige",
    name: "Prestige Estates Projects",
    category: "Real Estate",
    resolutionRate: "92.0%",
    avgDays: "6.3 Days",
    totalCases: 290,
    nodalEmail: "properties@prestigeconstructions.com",
    rating: 4.5,
    authority: "RERA Real Estate Regulatory Authority",
    sla: "48h Ack / 14 Days Target",
    badge: "RERA Nodal Desk",
    badgeColor: "#059669",
    color: "#059669",
  },
];

export default function BrandLeaderboard() {
  const [searchTerm, setSearchTerm] = useState("");
  const [selectedCategory, setSelectedCategory] = useState("All");
  const [copiedEmail, setCopiedEmail] = useState("");

  const handleCopyEmail = (email) => {
    navigator.clipboard.writeText(email);
    setCopiedEmail(email);
    setTimeout(() => setCopiedEmail(""), 2200);
  };

  const categories = [
    "All",
    "E-Commerce",
    "Food & Grocery",
    "Banking & UPI",
    "Telecom",
    "Travel & Mobility",
    "Electronics & Tech",
    "Home Appliances",
    "Automotive & EV",
    "Insurance & Health",
    "OTT & Media",
    "Logistics & Postal",
    "EdTech & Education",
    "Real Estate",
  ];

  const filteredBrands = BRAND_DATA.filter((brand) => {
    const matchesSearch =
      brand.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      brand.nodalEmail.toLowerCase().includes(searchTerm.toLowerCase()) ||
      brand.category.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesCategory = selectedCategory === "All" || brand.category === selectedCategory;
    return matchesSearch && matchesCategory;
  });

  return (
    <div className="brand-leaderboard-page">
      <ResolutionTicker />
      <div className="leaderboard-container">
        {/* Page Header */}
        <div className="leaderboard-header">
          <div className="header-badge">
            <FaShieldAlt /> Q3 2026 Community Redressal Benchmarks
          </div>
          <h1>Enterprise Redressal & Trust Index</h1>
          <p className="leaderboard-subtitle">
            Quarterly resolution metrics, turnaround benchmarks, and verified corporate grievance officer contact channels compiled from voluntary consumer dispute facilitations.
          </p>

          {/* Methodology Banner */}
          <div className="methodology-banner">
            <FaInfoCircle className="methodology-icon" />
            <span>
              <strong>Independent Platform Benchmark:</strong> Metrics are community scores compiled from verified user dispute dockets, verified enterprise resolution responses, and statutory nodal disclosures. Review our <Link to="/methodology" className="methodology-link">Brand Methodology & Takedown Policy</Link>. Enterprise grievance officers can resolve cases via the <Link to="/partner/resolve" className="methodology-link">Resolution Desk</Link>.
            </span>
          </div>

          {/* Top Metric Cards */}
          <div className="leaderboard-stat-cards">
            <div className="summary-stat-card green">
              <span className="stat-label">Average Redressal Rate</span>
              <strong className="stat-value">94.7%</strong>
              <span className="stat-hint">Across voluntary facilitated disputes</span>
            </div>
            <div className="summary-stat-card blue">
              <span className="stat-label">Avg. Turnaround Speed</span>
              <strong className="stat-value">3.1 Days</strong>
              <span className="stat-hint">Standard 7-day target window</span>
            </div>
            <div className="summary-stat-card purple">
              <span className="stat-label">Verified Corporate Desks</span>
              <strong className="stat-value">80+ Listed</strong>
              <span className="stat-hint">Direct 1-click tokenized desk</span>
            </div>
            <div className="summary-stat-card amber">
              <span className="stat-label">Average Citizen Rating</span>
              <strong className="stat-value">4.6 / 5.0</strong>
              <span className="stat-hint">Post-resolution community feedback</span>
            </div>
          </div>
        </div>

        {/* Controls: Search & Category Pills */}
        <div className="leaderboard-controls">
          <div className="search-bar-wrap">
            <FaSearch className="search-bar-icon" />
            <input
              type="text"
              placeholder="Search by enterprise or nodal desk (e.g. Amazon, PhonePe, SBI, Zomato, Tata, Samsung, LIC)..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
            />
            {searchTerm && (
              <button
                type="button"
                className="search-clear-btn"
                onClick={() => setSearchTerm("")}
                title="Clear search"
              >
                <FaTimes />
              </button>
            )}
          </div>

          <div className="category-pills-row">
            {categories.map((cat) => (
              <button
                key={cat}
                type="button"
                className={`category-pill-btn ${selectedCategory === cat ? "active" : ""}`}
                onClick={() => setSelectedCategory(cat)}
              >
                {cat}
              </button>
            ))}
          </div>

          <div className="filter-summary-row">
            <span>Showing <strong>{filteredBrands.length}</strong> enterprise{filteredBrands.length === 1 ? "" : "s"}</span>
            {selectedCategory !== "All" && (
              <span className="filter-active-tag">
                Category: <strong>{selectedCategory}</strong>
              </span>
            )}
          </div>
        </div>

        {/* Brand Scorecard Grid */}
        <div className="brands-grid">
          {filteredBrands.map((brand) => (
            <div key={brand.id} className="brand-scorecard">
              <div className="brand-card-top">
                <div className="brand-identity">
                  <div className="brand-avatar">
                    {brand.name.charAt(0)}
                  </div>
                  <div>
                    <span className="brand-category-pill">{brand.category}</span>
                    <h3 className="brand-title">{brand.name}</h3>
                  </div>
                </div>
                <div className="brand-status-col">
                  <span className="brand-status-tag">
                    {brand.badge}
                  </span>
                  {["Samsung", "SpiceJet", "Ola", "Flipkart", "BYJU", "Ola Electric"].some((n) => brand.name.includes(n)) && (
                    <Link to="/class-actions" className="brand-class-tag" title="View active collective consumer petition">
                      <FaUsers /> Class Petition
                    </Link>
                  )}
                </div>
              </div>

              {/* Redressal Progress Bar */}
              <div className="rate-progress-wrap">
                <div className="rate-progress-header">
                  <span>Resolution Rate</span>
                  <strong>{brand.resolutionRate}</strong>
                </div>
                <div className="rate-progress-track">
                  <div
                    className="rate-progress-fill"
                    style={{ width: brand.resolutionRate }}
                  />
                </div>
              </div>

              {/* Metrics Grid */}
              <div className="brand-kpis-grid">
                <div className="kpi-box">
                  <span className="kpi-label">Avg. Speed</span>
                  <strong className="kpi-val blue">{brand.avgDays}</strong>
                </div>
                <div className="kpi-box">
                  <span className="kpi-label">Volume</span>
                  <strong className="kpi-val">{brand.totalCases.toLocaleString()} cases</strong>
                </div>
                <div className="kpi-box">
                  <span className="kpi-label">Rating</span>
                  <strong className="kpi-val gold">
                    <FaStar style={{ fontSize: 10, marginRight: 2 }} /> {brand.rating}
                  </strong>
                </div>
              </div>

              {/* Nodal Desk Info */}
              <div className="brand-officer-box">
                <div className="officer-line officer-line-copyable">
                  <FaEnvelope className="officer-icon" />
                  <span className="officer-email" title={brand.nodalEmail}>
                    {brand.nodalEmail}
                  </span>
                  <button
                    type="button"
                    className={`btn-mini-copy ${copiedEmail === brand.nodalEmail ? "copied" : ""}`}
                    onClick={() => handleCopyEmail(brand.nodalEmail)}
                    title="Copy nodal email address"
                  >
                    {copiedEmail === brand.nodalEmail ? <><FaCheck /> Copied</> : <><FaCopy /> Copy</>}
                  </button>
                </div>
                <div className="officer-line">
                  <FaClock className="officer-icon" />
                  <span>SLA: <strong>{brand.sla}</strong></span>
                </div>
                <div className="officer-line">
                  <FaShieldAlt className="officer-icon" />
                  <span>{brand.authority}</span>
                </div>
              </div>

              {/* Card Action */}
              <div className="brand-card-action">
                <Link
                  to={`/register?company=${encodeURIComponent(brand.name)}`}
                  className="btn-dispute-enterprise"
                >
                  File Grievance with {brand.name} <FaArrowRight style={{ fontSize: 10 }} />
                </Link>
              </div>
            </div>
          ))}
        </div>

        {/* Empty State */}
        {filteredBrands.length === 0 && (
          <div className="no-brands-card">
            <FaBuilding className="empty-icon" />
            <h3>No enterprise found matching "{searchTerm}"</h3>
            <p>You can still file a dispute against any custom organization or retailer through our custom enterprise desk.</p>
            <div className="empty-actions">
              <button
                type="button"
                className="btn-reset-search"
                onClick={() => {
                  setSearchTerm("");
                  setSelectedCategory("All");
                }}
              >
                Clear Filters
              </button>
              <Link to="/register" className="btn-file-custom">
                File Custom Grievance <FaArrowRight />
              </Link>
            </div>
          </div>
        )}

        {/* ==========================================
            STATUTORY ESCALATION MATRIX DIRECTORY
            ========================================== */}
        <div className="escalation-matrix-section">
          <div className="matrix-header">
            <div className="matrix-badge">
              <FaGavel /> Statutory Escalation Framework
            </div>
            <h2>Sectoral Grievance Escalation Hierarchy</h2>
            <p>
              When an enterprise fails to acknowledge or resolve a dispute within the statutory SLA window, citizens are entitled to escalate across standardized Government & Regulatory tiers.
            </p>
          </div>

          <div className="matrix-grid">
            {/* Sector 1: Banking & UPI */}
            <div className="matrix-card">
              <div className="matrix-card-header">
                <span className="matrix-sector-tag">Banking, UPI & FinTech</span>
                <h3>RBI Integrated Ombudsman Scheme (2021)</h3>
                <p>Governs Banks, NBFCs, Payment System Operators (PhonePe, Paytm, Google Pay, Razorpay), and PPI issuers.</p>
              </div>
              <div className="matrix-levels-list">
                <div className="matrix-level-item">
                  <div className="level-badge l1">Level 1</div>
                  <div className="level-content">
                    <strong>Bank / FinTech Grievance Redressal Officer (GRO)</strong>
                    <span>Standard turnaround: <strong>48 hours Ack / 7–14 days Resolution</strong></span>
                  </div>
                </div>
                <div className="matrix-level-item">
                  <div className="level-badge l2">Level 2</div>
                  <div className="level-content">
                    <strong>Principal Nodal Officer (PNO)</strong>
                    <span>Internal appellate desk. Maximum turnaround: <strong>30 days total</strong></span>
                  </div>
                </div>
                <div className="matrix-level-item">
                  <div className="level-badge l3">Level 3</div>
                  <div className="level-content">
                    <strong>RBI Centralized Receipt & Processing Centre (CRPC)</strong>
                    <span>Statutory Ombudsman Portal: <a href="https://cms.rbi.org.in" target="_blank" rel="noopener noreferrer">cms.rbi.org.in <FaExternalLinkAlt style={{ fontSize: 9 }} /></a> • Toll-Free 14448</span>
                  </div>
                </div>
              </div>
            </div>

            {/* Sector 2: E-Commerce & Marketplaces */}
            <div className="matrix-card">
              <div className="matrix-card-header">
                <span className="matrix-sector-tag">E-Commerce & Digital Marketplaces</span>
                <h3>Consumer Protection (E-Commerce) Rules, 2020</h3>
                <p>Applies to Amazon, Flipkart, Myntra, Swiggy, Zomato, Blinkit, Zepto, and direct-to-consumer digital portals.</p>
              </div>
              <div className="matrix-levels-list">
                <div className="matrix-level-item">
                  <div className="level-badge l1">Level 1</div>
                  <div className="level-content">
                    <strong>Resident Grievance Officer (RGO)</strong>
                    <span>Mandatory under Rule 5(4). Acknowledgement within <strong>48 hours</strong>; Resolution within <strong>1 month</strong>.</span>
                  </div>
                </div>
                <div className="matrix-level-item">
                  <div className="level-badge l2">Level 2</div>
                  <div className="level-content">
                    <strong>National Consumer Helpline (NCH 1915)</strong>
                    <span>DoCA pre-litigation conciliation via Toll-Free 1915 or <a href="https://consumerhelpline.gov.in" target="_blank" rel="noopener noreferrer">consumerhelpline.gov.in <FaExternalLinkAlt style={{ fontSize: 9 }} /></a></span>
                  </div>
                </div>
                <div className="matrix-level-item">
                  <div className="level-badge l3">Level 3</div>
                  <div className="level-content">
                    <strong>e-Daakhil Online Consumer Court / CCPA</strong>
                    <span>File formal complaint under Section 35 CPA 2019 via <a href="https://edaakhil.nic.in" target="_blank" rel="noopener noreferrer">edaakhil.nic.in <FaExternalLinkAlt style={{ fontSize: 9 }} /></a></span>
                  </div>
                </div>
              </div>
            </div>

            {/* Sector 3: Telecom & Internet */}
            <div className="matrix-card">
              <div className="matrix-card-header">
                <span className="matrix-sector-tag">Telecom, 5G & Broadband</span>
                <h3>TRAI Telecom Consumers Protection Regulations</h3>
                <p>Covers Jio, Airtel, Vodafone Idea, BSNL, ACT Fibernet, and registered internet service providers.</p>
              </div>
              <div className="matrix-levels-list">
                <div className="matrix-level-item">
                  <div className="level-badge l1">Level 1</div>
                  <div className="level-content">
                    <strong>Telecom Service Provider Call Centre & Grievance Desk</strong>
                    <span>Docket number generation with maximum <strong>3–7 days resolution TAT</strong>.</span>
                  </div>
                </div>
                <div className="matrix-level-item">
                  <div className="level-badge l2">Level 2</div>
                  <div className="level-content">
                    <strong>Appellate Authority (Designated Senior Officer)</strong>
                    <span>Appeal within 30 days of Call Centre rejection. Resolution TAT: <strong>10 working days</strong>.</span>
                  </div>
                </div>
                <div className="matrix-level-item">
                  <div className="level-badge l3">Level 3</div>
                  <div className="level-content">
                    <strong>TRAI / DoT Consumer Grievances & Consumer Forum</strong>
                    <span>Statutory recourse under Consumer Protection Act 2019 for unfair trade practices or billing errors.</span>
                  </div>
                </div>
              </div>
            </div>

            {/* Sector 4: Insurance (Life, Health, Motor) */}
            <div className="matrix-card">
              <div className="matrix-card-header">
                <span className="matrix-sector-tag">Life, Health & General Insurance</span>
                <h3>IRDAI Protection of Policyholders' Interests Regulations</h3>
                <p>Governs LIC, Star Health, HDFC ERGO, ICICI Lombard, Niva Bupa, Care Insurance, and Bajaj Allianz.</p>
              </div>
              <div className="matrix-levels-list">
                <div className="matrix-level-item">
                  <div className="level-badge l1">Level 1</div>
                  <div className="level-content">
                    <strong>Grievance Redressal Officer (GRO) of Insurance Company</strong>
                    <span>Mandatory acknowledgement within <strong>3 days</strong>; Resolution within <strong>14 days</strong>.</span>
                  </div>
                </div>
                <div className="matrix-level-item">
                  <div className="level-badge l2">Level 2</div>
                  <div className="level-content">
                    <strong>IRDAI Bima Bharosa Portal (EPMS)</strong>
                    <span>Online escalation via <a href="https://bimabharosa.irdai.gov.in" target="_blank" rel="noopener noreferrer">bimabharosa.irdai.gov.in <FaExternalLinkAlt style={{ fontSize: 9 }} /></a> or Toll-Free 155255.</span>
                  </div>
                </div>
                <div className="matrix-level-item">
                  <div className="level-badge l3">Level 3</div>
                  <div className="level-content">
                    <strong>Council for Insurance Ombudsmen (CIO)</strong>
                    <span>Binding quasi-judicial awards up to ₹50 Lakhs within 3 months under Insurance Ombudsman Rules 2017.</span>
                  </div>
                </div>
              </div>
            </div>

            {/* Sector 5: Airlines & Aviation */}
            <div className="matrix-card">
              <div className="matrix-card-header">
                <span className="matrix-sector-tag">Aviation & Airlines</span>
                <h3>DGCA Civil Aviation Requirements (CAR Section 3)</h3>
                <p>Applies to IndiGo, Air India, SpiceJet, Akasa Air, and flight booking travel aggregators.</p>
              </div>
              <div className="matrix-levels-list">
                <div className="matrix-level-item">
                  <div className="level-badge l1">Level 1</div>
                  <div className="level-content">
                    <strong>Airline Passenger Grievance Redressal Officer</strong>
                    <span>Mandatory written resolution within <strong>30 days</strong> of complaint submission.</span>
                  </div>
                </div>
                <div className="matrix-level-item">
                  <div className="level-badge l2">Level 2</div>
                  <div className="level-content">
                    <strong>Ministry of Civil Aviation — AirSewa Portal</strong>
                    <span>Government appellate platform via <a href="https://airsewa.gov.in" target="_blank" rel="noopener noreferrer">airsewa.gov.in <FaExternalLinkAlt style={{ fontSize: 9 }} /></a> • Nodal Officer Escalation.</span>
                  </div>
                </div>
                <div className="matrix-level-item">
                  <div className="level-badge l3">Level 3</div>
                  <div className="level-content">
                    <strong>District Consumer Commission (DCDRC)</strong>
                    <span>Statutory claim for statutory delay/cancellation compensation and refund of denied boarding.</span>
                  </div>
                </div>
              </div>
            </div>

            {/* Sector 6: Real Estate & Housing */}
            <div className="matrix-card">
              <div className="matrix-card-header">
                <span className="matrix-sector-tag">Real Estate & Construction</span>
                <h3>RERA (Real Estate Regulation & Development Act, 2016)</h3>
                <p>Covers DLF, Godrej Properties, Lodha, Sobha, Prestige, and state-registered builders.</p>
              </div>
              <div className="matrix-levels-list">
                <div className="matrix-level-item">
                  <div className="level-badge l1">Level 1</div>
                  <div className="level-content">
                    <strong>Developer / Builder Grievance Desk</strong>
                    <span>Direct statutory pre-litigation notice demanding possession or interest for delay.</span>
                  </div>
                </div>
                <div className="matrix-level-item">
                  <div className="level-badge l2">Level 2</div>
                  <div className="level-content">
                    <strong>State Real Estate Regulatory Authority (RERA)</strong>
                    <span>Filing before State RERA (e.g., MahaRERA, HRERA, UP RERA) for delay compensation or refund.</span>
                  </div>
                </div>
                <div className="matrix-level-item">
                  <div className="level-badge l3">Level 3</div>
                  <div className="level-content">
                    <strong>RERA Appellate Tribunal (REAT) & Consumer Court</strong>
                    <span>High-level adjudication with execution warrants under RERA Section 40.</span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
